from django.apps import AppConfig


class QuickBuyConfig(AppConfig):
    name = 'quick_buy'
