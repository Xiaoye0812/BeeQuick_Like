from django.apps import AppConfig


class MineConfig(AppConfig):
    name = 'mine'
